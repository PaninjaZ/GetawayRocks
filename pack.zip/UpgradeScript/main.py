#https://github.com/PaninjaZ/GetawayRocks/releases/latest/download/GoAwayRocks.zip

import sys
import requests
import zipfile
import os
sys.path.insert(0,'file')

print("---------- Loading...")

url = 'https://github.com/PaninjaZ/GetawayRocks/releases/latest/download/GoAwayRocks.zip'
r = requests.get(url, allow_redirects=True)

print("/////----- Loading...")

#open('facebook.ico', 'wb').write(r.content)

import os

cur_path = os.path.dirname(__file__)

if getattr(sys, 'frozen', False):
    application_path = os.path.dirname(sys.executable)
elif __file__:
    application_path = os.path.dirname(__file__)

config_path = os.path.join(application_path)

new_path = config_path + "/game.zip"

print("///////--- Loading...")

with open(new_path, 'wb') as f:
    f.write(r.content)
    
print("////////// Loading...")
print("Completed!")

with zipfile.ZipFile(new_path, 'r') as zip_ref:
    zip_ref.extractall(config_path)


if os.path.exists(config_path+"/game.zip"):
  os.remove(config_path+"/game.zip")
else:
  print("The file does not exist")